<!DOCTYPE html>
<html>
<head>
    <title></title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
</head>
<body>


<?php
include '../Model/model.php';
session_start();
if(isset($_GET['cat_id'])){
    $_SESSION['cat_id'] = $_GET['cat_id'];
}


?>
<form action="../Controller/add_product.php" method="post" enctype="multipart/form-data">
    <input type="text" name="name" placeholder="Name">
    <input type="text" name="desc" placeholder="Description">
    <input type="text" name="price" placeholder="Price">
    <input type="file" name="img">
    <button name="action" value="add">Add product</button>
</form>


<?php
$model = new Model();
$all = $model->get_products($_SESSION['cat_id']);
// print_r($all);
?>




<table>
    <tr>
        <th>Name</th>
        <th>Image</th>
        <th>Description</th>
        <th>Price</th>
        <th>Update</th>
        <th>Delete</th>
    </tr>
    <?php

    for($i=0;$i<count($all);$i++){?>
        <tr id="<?=$all[$i]['id']?>">
            <td class="td_name" contenteditable>
                <?=$all[$i]['name']?></td>
            <td><img src="../Assets/images/<?=$all[$i]['image']?>" width="100" height="100"></td>

            <td ><p class="td_desc"contenteditable><?=$all[$i]['description']?></p></td>
            <td><p contenteditable class="p_price"><?=$all[$i]['price']?></p></td>
            <td><button class="btn_upd">Update</button></td>
            <td><button class="btn_del">Delete</button></td>
        </tr>

    <?php } ?>

</table>


<script type="text/javascript">
    $(document).ready(function(){
        $('.btn_upd').click(function(){
            console.log(1);

            let self = $(this).parents('tr');
            let id = self.attr('id');
            let name = self.find('.td_name').text();
            let desc = self.find('.td_desc').text();
            let price = self.find('.p_price').text();

            $.ajax({
                url: '../Controller/add_product.php',
                method: 'post',
                data: {
                    name,
                    desc,
                    price,
                    id,
                    action: 'update',
                },
                success: function(){
                    location.reload();
                },
            })
        });

        $('.btn_del').click(function(){
            let id = $(this).parents('tr').attr('id');
            $.ajax({
                url: '../Controller/add_product.php',
                method: 'post',
                data: {
                    id,
                    action: 'delete',
                },
                success: function(){
                    location.reload();
                },

            })
        });

    });
</script>
</body>
</html>
