<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="../Assets/JS/script.js"></script>
</head>
<body>
    <a href="../Controller/logout.php">Log Out</a>
    <?php
    session_start();
    include '../Model/model.php';
    if (!isset($_SESSION['admin'])) {
        header('location: ../index.php');
        die;
    }
    echo "Welcome home " .$_SESSION['admin']."<br>";
    ?>

    <input type="text" id="inp">
    <button id="btn_add" name="add">Add</button>
    <p id="p_mess"></p>

    <?php
    $all = $model->get_categories();
    ?>

    <table>
        <tr>
            <th>Name</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>

        <?php
            for ($i=0; $i < count($all); $i++) { ?>
                <tr id="<?= $all[$i]['id']?>">
                    <td contenteditable="true"><?= $all[$i]['name'] ?></td>
                    <td><button class="btn_upd">Update</button></td>
                    <td><button class="btn_del">Delete</button></td>
                    <td><a href="product.php?cat_id=<?=$all[$i]['id']?>">Show</a></td>
                </tr>
        <?php }?>
    </table>



</body>
</html>


