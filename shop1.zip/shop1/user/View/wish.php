<?php
include 'header.php';
include '../Model/user_model.php';

if(!isset($_SESSION['user_id'])){
    $_SESSION['error'] = 'Please log in first';
    header('location: login_form.php');
    die;
}
// $user_model = new user_model();
$user_id = $_SESSION['user_id'];
$all = $user_model->get_wish_items($user_id);
if(!count($all)){
    echo "<h2>Your wish-list is empty! </h2>";
    die;
}


?>

<table>
    <tr>
        <th>Name</th>
        <th>Image</th>
        <th>Description</th>
        <th>Price</th>
        <th>Add to card</th>
        <th>Remove</th>
    </tr>
    <?php 
        $total = 0;
        for($i=0; $i < count($all); $i++){ 
            $price = $all[$i]['price'];
            $prod_id = $all[$i]['product_id'];
        ?>
        <tr id="<?=$all[$i]['id']?>">
        <td class="td_name"><<?=$all[$i]['name']?></td>
        <td><img src="../Assets/images/<?=$all[$i]['image']?>" width="100" height="100"></td>
        <td><p class="td_desc"><?=$all[$i]['description']?></p></td>
        <td><p class="p_price"><?= $price ?></p>
    </td>
        <td><button id="<?=$prod_id?>" class="btn_wish_to_card">Add to card</button>
        <button class="btn_remove">Remove</button>
    </td>
    </tr>

    <?php } 

    ?>
</table>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

<script>
    $(function(){
        
        $('.btn_remove').click(function(){
            let id = $(this).parents('tr').attr('id');
            $.ajax({
                url:"../Controller/add_to_wish.php",
                method:'post',
                data:{
                    id,
                    action:'delete',
                    success:function(){
                        location.reload();
                    }
                }
            })
        })


        $('.btn_wish_to_card').click(function(){
            let id = $(this).attr('id');
            $.ajax({
                url:"../Controller/add_to_card.php",
                method:'post',
                dataType:'json',
                data:{
                    id,
                    action:'add',
                    success:function(){
                        if(!res.success){
                            location.href = 'login_form.php';
                        }
                    }
                }
            })
        })

    })
</script>
