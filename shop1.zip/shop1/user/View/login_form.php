<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <style>
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }
        body{
            height: 100vh;
            background: linear-gradient(
                #000,
                #00bb4a
            ) 0 100% no-repeat;
            background-size: 100% 50%;
        }
        .div_big1{
            width: 500px;
            padding: 90px;
            position: absolute;
            transform: translate(-50%, -50%);
            top: 50%;
            left: 50%;
            background-color: #fff;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.651);
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .div_form{
            padding: 10px;
        }
        .inputs{
            padding: 10px;
            margin: 10px;
            border: none;
            border-bottom: 1px solid;
        }
        .btn{
            padding: 10px;
            width: 100px;
            margin: 10px;
            border: none;
            background-color: #00bb4a;
            cursor: pointer;
            border-radius: 10px;
            color: #fff;
            font-size: 17px;
        }
        .checkbox{
            margin: 10px;
        }
    </style>
</head>
<body>
<div class="div_big1">
    <div class="div_form">
        <form action="../Controller/login.php" method="post">
            <input type="email" name="email" placeholder="Email" class="inputs"><br>
            <input type="password" name="pass" placeholder="Password" class="inputs"><br>
            <input type="checkbox" name="inp_check" class="checkbox">
            <button name="btn_login" value="btn" class="btn">Login</button>
        </form>
        <p style="text-align: center;">
            <?php
                if(isset($_SESSION['error'])){
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                }
            ?>
        </p>
    </div>
</div>
</body>
</html>