<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
<?php
include 'header.php';
include '../Model/user_model.php';
if(isset($_GET['cat_id'])){
    $_SESSION['cat_id'] = $_GET['cat_id'];
}

$all = $user_model->get_product($_SESSION['cat_id']);
// echo '<pre>';
// print_r($all);

?>

<table>
    <tr>
        <th>Name</th>
        <th>Image</th>
        <th>Description</th>
        <th>Price</th>
    </tr>
    <?php
    for($i = 0; $i < count($all); $i++){ ?>
        <tr id="<?=$all[$i]["id"]?>">
            <td class="td_name"><?=$all[$i]['name']?></td>
            <td><img src="../Assets/images/<?=$all[$i]['image']?>" width="100" height="100"></td>
            <td><p class="td_desc"><?=$all[$i]['description']?></p></td>
            <td><p class="td_price"><?=$all[$i]['price']?></p></td>
            <td><button class="btn_add">Add to card</button></td>
            <td><button class="btn_wish">Add to wish card</button></td>
        </tr>
    <?php } ?>
</table>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>
    $(function(){
        $(".btn_add").click(function(){
            let id = $(this).parents('tr').attr('id');
            $.ajax({
                url: "../Controller/add_to_card.php",
                method: "post",
                dataType: "json",
                data:{
                    id,
                    action:'add',
                },
                success:function(res){
                    if(!res.success){
                        location.href = "login_form.php"
                    }else{
                        console.log(res);
                    }
                }
            })
        })

        $('.btn_wish').click(function(){
            let id = $(this).parents('tr').attr('id');
            $.ajax({
                url: "../Controller/add_to_wish.php",
                method: "post",
                dataType: "json",
                data:{
                    id,
                    action:'add',
                },
                success:function(res){
                    if(!res.success){
                        location.href = "login_form.php"
                    }else{
                        console.log(res);
                    }
                }
            })       
        })
    })



</script>


</body>
</html>