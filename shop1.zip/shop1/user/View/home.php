<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="../Controller/logout.php">Log Out</a>
    <?php
    session_start();
    include '../Model/model.php';
    if (!isset($_SESSION['admin'])) {
        header('location: ../index.php');
        die;
    }
    echo "Welcome home " .$_SESSION['admin']."<br>";
    ?>

    <input type="text" id="inp">
    <button id="btn_add" name="add">Add</button>

    <?php
    $all = $model->get_categories();
    ?>
</body>
</html>


