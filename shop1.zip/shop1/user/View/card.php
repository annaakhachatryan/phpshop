<?php
include 'header.php';
include '../Model/user_model.php';

if(!isset($_SESSION['user_id'])){
    $_SESSION['error'] = 'Please log in first';
    header('location: login_form.php');
    die;
}
// $user_model = new user_model();

$user_id = $_SESSION['user_id'];
$all = $user_model->get_card_items($user_id);
if(!count($all)){
    echo "<h2>Your card is empty! </h2>";
    die;
}


?>

<table>
    <tr>
        <th>Name</th>
        <th>Image</th>
        <th>Description</th>
        <th>Price</th>
        <th>Sum</th>
        <th>Remove</th>
    </tr>
    <?php 
        $total = 0;
        for($i=0; $i < count($all); $i++){ 
            $price = $all[$i]['price'];
            $quantity = $all[$i]['quantity'];
            $sum = $price + $quantity;
            $total += $sum;
        ?>
        <tr id="<?=$all[$i]['id']?>">
        <td class="td_name"><<?=$all[$i]['name']?></td>
        <td><img src="../Assets/images/<?=$all[$i]['image']?>" width="100" height="100"></td>
        <td><p class="td_desc"><?=$all[$i]['description']?></p></td>
        <td><p class="p_price"><?= $price ?></p></td>
        <td><button class="minus">-</button>
        <span class="quant"><?=$all[$i]['quantity']?></span>
    </td>
        <td><button class="plus">+</button></td>
        <td><input type="number" class="inp_quantity" value="<?$quantity?>"></td>
        <td><p class="sum"><?$sum?></p></td>
        <td><button class="btn_remove">Remove</button></td>
    </tr>

    <?php } 

    echo "<tr><td colspan='6'> Total </td> <td class='total'> $total </td></tr>";

    ?>
    <tr>
        <td colspan='7' align="center">
            <button name='btn_buy' style="background-color: red;">
            <a style="color: white; text-decoration: none" href="../Controller/buy.php">Buy</a>
        </button>
        </td>
    </tr>

</table>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

<script>
    $(function(){
        $('.plus').click(function(){
            let price = $(this).parents('tr').find('.p_price').html();
            let quant = $(this).parents('tr').find('.quant').html();
            let total = $(this).parents('tr').find('.total').html();
            let id = $(this).parents('tr').attr('id');
            console.log(price + "" + quant + "" + total) ;
            quant++;
            $(this).parents('tr').find('.quant').html(quant);
            $('tr').find('.total').html(quant*price);
            $.ajax({
                url:"../Controller/add_to_card.php",
                method:'post',
                data:{
                    quant, id,
                    action:'update',
                    success:function(res){
                        location.reload();
                    }
                }
            })
        })



        $('.minus').click(function(){
            let price = $(this).parents('tr').find('.p_price').html();
            let quant = $(this).parents('tr').find('.quant').html();
            let total = $(this).parents('tr').find('.total').html();
            let id = $(this).parents('tr').attr('id');
            if(quant>1){
                quant--;
            $(this).parents('tr').find('.quant').html(quant);
            $('tr').find('.total').html(quant*price);
            $.ajax({
                url:"../Controller/add_to_card.php",
                method:'post',
                data:{
                    quant, id,
                    action:'update',
                    success:function(res){
                        location.reload();
                    }
                }
            })
        }
        })


        $('.btn_remove').click(function(){
            let id = $(this).parents('tr').attr('id');
            $.ajax({
                url:"../Controller/add_to_card.php",
                method:'post',
                data:{
                    id,
                    action:'update',
                    success:function(){
                        location.reload();
                    }
                }
            })
        })

    })
</script>
