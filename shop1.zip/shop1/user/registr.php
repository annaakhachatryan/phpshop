<?php
$localhost = "localhost";
$dUser = "root";
$dPassword = "";
$dName = "login_register";
$conn = mysqli_connect($localhost, $dUser, $dPassword, $dName);
if(!$conn){
    die("Something went wrong!");
}
?>