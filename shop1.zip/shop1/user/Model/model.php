<?php
class Model{
    public $conn;
    public function __construct(){
        $this->conn = mysqli_connect('localhost', 'root','', 'shop');
        if(!$this->conn){
            die(mysqli_connect_error($this->conn));
        }
    }

    public function __destruct(){
        mysqli_close($this->conn);
    }

    public function admin($login, $pass){
        $query = "SELECT * FROM admin WHERE login='$login' AND password= '$pass'";
        $res = mysqli_query($this->conn, $query);
        // veradarcnum e ardyunqi toxeri qanaky
        return mysqli_num_rows($res);
    }

    public function add_category($name){
        $query = "INSERT INTO categories(name) VALUES('$name')";
        $res = mysqli_query($this->conn, $query);
    }

    public function get_categories(){
        $query = "SELECT * FROM categories";
        $res = mysqli_query($this->conn, $query);
        $result = mysqli_fetch_all($res, MYSQLI_ASSOC);
        return $result;
    }
}

$model = new Model();

?>