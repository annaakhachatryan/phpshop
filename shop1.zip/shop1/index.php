<?php

include 'User/View/header.php';
include 'User/Model/user_model.php';

?>

<div>
    <?php
        $all = $user_model->get_categories();
        // echo '<pre>';
        // print_r($all);
    ?>

    <table>
        <tr>
            <th class="th_categories">Categories</th>
        </tr>
    </table>

    <?php
        for ($i=0; $i < count($all); $i++) { ?>
        <tr id="<?=$all[$i]['id']?>">
            <td class="td_categories"><?=$all[$i]['name']?></td>
            <td><a href="user/View/products.php?cat_id=<?=$all[$i]['id']?>">Show</a></td>
        </tr>
    <?php } ?>
</div>

